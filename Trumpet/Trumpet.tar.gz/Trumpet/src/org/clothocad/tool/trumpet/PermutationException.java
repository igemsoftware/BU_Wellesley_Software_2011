package org.clothocad.tool.trumpet;



/**
 *
 * @author Craig LaBoda
 *
 */

public class PermutationException extends Exception{

    public PermutationException(String message)
    {
        super(message);
    }
    
}
